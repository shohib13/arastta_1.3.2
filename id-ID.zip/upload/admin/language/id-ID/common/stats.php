<?php
/**
 * @package		Arastta eCommerce
 * @copyright	Copyright (C) 2015 Arastta Association. All rights reserved. (arastta.org)
 * @credits		See CREDITS.txt for credits and other copyright notices.
 * @license		GNU General Public License version 3; see LICENSE.txt
 */
$_['heading_title']    		 = 'Statuses';
$_['text_complete_status']   = 'Pesanan Selesai'; 
$_['text_processing_status'] = 'Pesanan Diproses'; 
$_['text_other_status']      = 'Status Lainnya'; 