<?php
/**
 * @package		Arastta eCommerce
 * @copyright	Copyright (C) 2015 Arastta Association. All rights reserved. (arastta.org)
 * @license		GNU General Public License version 3; see LICENSE.txt
 */

// Heading
$_['heading_title']  = 'Halaman Tidak Ditemukan!';

// Text
$_['text_not_found'] = 'Halaman yang anda cari tidak dapat ditemukan! Silakan hubungi administrator jika masalah masih berlanjut.';