<?php
/**
 * @package		Arastta eCommerce
 * @copyright	Copyright (C) 2015 Arastta Association. All rights reserved. (arastta.org)
 * @license		GNU General Public License version 3; see LICENSE.txt
 */

// Text
$_['text_subject']  = '%s - Permintaan reset kata sandi';
$_['text_greeting'] = 'Sebuah kata sandi baru telah diajukan untuk administrasi %s .';
$_['text_change']   = 'Untuk me-reset kata sandi anda silahkan klik tautan di bawah ini :';
$_['text_ip']       = 'IP yang digunakan untuk permintaan ini adalah : %s';