<?php
/**
 * @package		Arastta eCommerce
 * @copyright	Copyright (C) 2015 Arastta Association. All rights reserved. (arastta.org)
 * @license		GNU General Public License version 3; see LICENSE.txt
 */

// Text
$_['text_subject']       = '%s - Pembaruan Retur  %s';
$_['text_return_id']     = 'ID Retur:';
$_['text_date_added']    = 'Tanggal Retur:';
$_['text_return_status'] = 'Retur anda telah diperbarui untuk status berikut:';
$_['text_comment']       = 'Komentar untuk retur anda adalah:';
$_['text_footer']        = 'Silakan balas ke email ini jika anda memiliki pertanyaan.';