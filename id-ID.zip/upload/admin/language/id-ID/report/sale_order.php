<?php
/**
 * @package		Arastta eCommerce
 * @copyright	Copyright (C) 2015 Arastta Association. All rights reserved. (arastta.org)
 * @license		GNU General Public License version 3; see LICENSE.txt
 */

// Heading
$_['heading_title']     = 'Laporan Penjualan';

// Text
$_['text_list']         = 'Daftar penjualan';
$_['text_year']         = 'Tahun';
$_['text_month']        = 'Bulan';
$_['text_week']         = 'Minggu';
$_['text_day']          = 'Hari';
$_['text_all_status']   = 'Semua Status';

// Column
$_['column_date_start'] = 'Tanggal Mulai';
$_['column_date_end']   = 'Tanggal akhir';
$_['column_orders']     = 'No. Pesanan';
$_['column_products']   = 'No. Produk';
$_['column_tax']        = 'Pajak';
$_['column_total']      = 'Jumlah';

// Entry
$_['entry_date_start']  = 'Tanggal Mulai';
$_['entry_date_end']    = 'Tanggal akhir';
$_['entry_group']       = 'Kelompokan menurut';
$_['entry_status']      = 'Status Pemesanan';