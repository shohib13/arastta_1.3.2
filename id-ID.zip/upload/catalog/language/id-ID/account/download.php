<?php
/**
 * @package		Arastta eCommerce
 * @copyright	Copyright (C) 2015 Arastta Association. All rights reserved. (arastta.org)
 * @license		GNU General Public License version 3; see LICENSE.txt
 */

// Heading
$_['heading_title']     = 'Akun download';

// Text
$_['text_account']      = 'Akun';
$_['text_downloads']    = 'Unduhan';
$_['text_empty']        = 'Anda belum membuat pesanan download sebelumnya!';

// Column
$_['column_order_id']   = 'ID Pesanan';
$_['column_name']       = 'Nama';
$_['column_size']       = 'ukuran';
$_['column_date_added'] = 'Tanggal Ditambahkan';