<?php
/**
 * @package		Arastta eCommerce
 * @copyright	Copyright (C) 2015 Arastta Association. All rights reserved. (arastta.org)
 * @license		GNU General Public License version 3; see LICENSE.txt
 */

// Heading
$_['heading_title'] = 'Keluar Account';

// Text
$_['text_message']  = '<p>Anda Telah keluar dari Akun Afiliasi anda.</p>';
$_['text_account']  = 'Akun';
$_['text_logout']   = 'Log Keluar';