<?php
/**
 * @package		Arastta eCommerce
 * @copyright	Copyright (C) 2015 Arastta Association. All rights reserved. (arastta.org)
 * @license		GNU General Public License version 3; see LICENSE.txt
 */

// Heading
$_['heading_title']        = 'Pesanan Anda telah dimasukkan!';

// Text
$_['text_basket']          = 'Keranjang Belanja';
$_['text_checkout']        = 'Checkout / Menuju Kasir';
$_['text_success']         = 'Berhasil';
$_['text_customer']        = '<p>Pesanan Anda telah berhasil diproses!</p><p>Anda dapat melihat riwayat pemesanan anda mealaui halaman <a href="%s">akun saya</a> dengan mengklik <a href="%s">riwayat</a>. </p><p>Jika pembelian anda memiliki kaitan dengan men-download, anda bisa menuju halaman <a href="%s">Download </a> untuk melihatnya.</p><p>Silahkan kirimkan pertanyaan anda ke <a href="%s">pemilik toko</a>.</p><p>Terima kasih telah berbelanja online bersama kami!</p>';
$_['text_guest']           = '<p>Pesanan anda berhasil diproses!</p><p>Jika memiliki pertanyaan silahkan langsung ke <a href="%s">pemilik toko</a>.</p><p>Terima kasih telah belanja online bersama kami!</p>';