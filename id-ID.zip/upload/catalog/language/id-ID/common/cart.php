<?php
/**
 * @package		Arastta eCommerce
 * @copyright	Copyright (C) 2015 Arastta Association. All rights reserved. (arastta.org)
 * @license		GNU General Public License version 3; see LICENSE.txt
 */

// Text
$_['text_items']     = '%s item(s) - %s';
$_['text_empty']     = 'Daftar belanja Anda kosong!';
$_['text_cart']      = 'Lihat Keranjang';
$_['text_checkout']  = 'Keluar';
$_['text_recurring'] = 'Profil Pembayaran';