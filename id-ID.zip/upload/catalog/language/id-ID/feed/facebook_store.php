<?php
/**
 * @package        Arastta eCommerce
 * @copyright      Copyright (C) 2015 Arastta Association. All rights reserved. (arastta.org)
 * @credits        See CREDITS.txt for credits and other copyright notices.
 * @license        GNU General Public License version 3; see LICENSE.txt
 */

// Heading
$_['heading_title']                   = 'Facebook Store Feed';

// Text
$_['text_not_active_facebook_store']  = 'Facebook Store feed not active.Please active then test again.';