<?php
/**
 * @package		Arastta eCommerce
 * @copyright	Copyright (C) 2015 Arastta Association. All rights reserved. (arastta.org)
 * @license		GNU General Public License version 3; see LICENSE.txt
 */

// Text
$_['text_subject']  = '%s - kata sandi baru';
$_['text_greeting'] = 'Sebuah password baru yang diminta dari %s.';
$_['text_password'] = 'Kata sandi terkini Anda adalah:';