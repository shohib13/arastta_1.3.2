<?php
/**
 * @package		Arastta eCommerce
 * @copyright	Copyright (C) 2015 Arastta Association. All rights reserved. (arastta.org)
 * @license		GNU General Public License version 3; see LICENSE.txt
 */

// Text
$_['text_subject']	= '%s - Ulas Produk';
$_['text_waiting']	= 'Anda memiliki Tinjauan Produk baru yang menunggu anda.';
$_['text_product']	= 'Produk: %s';
$_['text_reviewer']	= 'Peninjau: %s';
$_['text_rating']	= 'Peringkat: %s';
$_['text_review']	= 'Teks Tinjauan:';