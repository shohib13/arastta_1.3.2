<?php
/**
 * @package		Arastta eCommerce
 * @copyright	Copyright (C) 2015 Arastta Association. All rights reserved. (arastta.org)
 * @license		GNU General Public License version 3; see LICENSE.txt
 */

// Text
$_['text_title']				= 'Transfer Bank';
$_['text_instruction']			= 'Instruksi Transfer Bank';
$_['text_description']			= 'Silakan transfer jumlah total ke rekening bank berikut ini.';
$_['text_payment']				= 'Pesanan anda tidak akan kami kirim sampai kami menerima pembayaran.';