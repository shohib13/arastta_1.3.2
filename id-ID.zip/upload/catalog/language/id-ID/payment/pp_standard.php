<?php
/**
 * @package		Arastta eCommerce
 * @copyright	Copyright (C) 2015 Arastta Association. All rights reserved. (arastta.org)
 * @license		GNU General Public License version 3; see LICENSE.txt
 */

// Text
$_['text_title']	= 'PayPal';
$_['text_testmode']	= 'Peringatan: Pembayaran gateway di \'Sandbox Mode\'. Akun Anda tidak akan dikenakan biaya.';
$_['text_total']	= 'Pengiriman, penanganan, diskon & pajak';