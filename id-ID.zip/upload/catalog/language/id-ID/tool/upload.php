<?php
/**
 * @package		Arastta eCommerce
 * @copyright	Copyright (C) 2015 Arastta Association. All rights reserved. (arastta.org)
 * @license		GNU General Public License version 3; see LICENSE.txt
 */

// Text
$_['text_upload']    = 'File anda berhasil diupload!';

// Error
$_['error_filename'] = 'Namafile harus antara 3 dan 128 karakter!';
$_['error_filetype'] = 'Jenis berkas tidak valid!';
$_['error_upload']   = 'Upload Diperlukan!';
